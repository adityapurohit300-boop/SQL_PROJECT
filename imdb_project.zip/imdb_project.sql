show databases;
--  select database

use project_movie_database;

-- ckeck tables
show tables;
describe directors;

-- a) get all data about movies and directors

select * from directors;

select * from movies;
describe movies;


-- b) how many movies are present

select count(original_title) from movies;

-- c)  find directors james cameron,luc besson, john woo
select * from directors where name in ('James Cameron','Luc Besson','John Woo');

-- d) directors whose names starts with s 
select * from directors where name like 's%';

-- e)count female directors

select count('gender') from directors where gender=1;

-- f) find the 10th female director

select name from directors  where gender=1 limit 9,1;

-- g) top 3 most popular movies

select original_title,popularity from movies order by popularity desc limit 3;

-- h) most awarded moviesafter jan 1 , 2000
select original_title,vote_average from movies where release_date >= '2000-01-01' order  by vote_average desc limit 1 ;

-- j) movie directed by brenda chapman
SELECT m.original_title, d.name FROM movies m INNER JOIN directors d ON m.director_id = d.id WHERE d.name LIKE '%Brenda Chapman%';

-- h) directors who made the most movies 

select d.name,COUNT(*) AS Total_Movies from directors d join movies m on d.id = m.director_id group by d.name order by Total_Movies desc limit 1; 

-- i) most bankable directors
select d.name,SUM(m.revenue) as Total_Revenue from directors d join movies m on d.id = m.director_id group by d.name order by Total_Revenue desc limit 1;
